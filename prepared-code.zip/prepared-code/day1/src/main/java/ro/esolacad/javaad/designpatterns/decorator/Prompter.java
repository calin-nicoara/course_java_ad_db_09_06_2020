package ro.esolacad.javaad.designpatterns.decorator;

interface Prompter {
    void giveYourRegards(String regards);

    String helloThere();
}
