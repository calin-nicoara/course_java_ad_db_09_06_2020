package ro.esolacad.javaad.designpatterns.di;

public interface Motor {

    void goFast();
}
