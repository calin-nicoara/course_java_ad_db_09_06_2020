package ro.esolacad.javaad.designpatterns.factory;

class FactoryExample {


}
