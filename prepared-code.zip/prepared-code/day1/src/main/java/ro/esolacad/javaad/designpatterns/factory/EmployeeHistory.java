package ro.esolacad.javaad.designpatterns.factory;

import java.util.List;

interface EmployeeHistory {

    List<String> getFormerEmployees();
}
