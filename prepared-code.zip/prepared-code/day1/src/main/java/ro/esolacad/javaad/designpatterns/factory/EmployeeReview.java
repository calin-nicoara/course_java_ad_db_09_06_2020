package ro.esolacad.javaad.designpatterns.factory;

interface EmployeeReview {

    Integer getScore();
}
