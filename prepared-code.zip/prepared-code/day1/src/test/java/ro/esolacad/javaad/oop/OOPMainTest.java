package ro.esolacad.javaad.oop;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OOPMainTest {

    @Test
    public void test() {

    }
}
