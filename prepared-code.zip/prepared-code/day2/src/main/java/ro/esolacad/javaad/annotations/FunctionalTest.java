package ro.esolacad.javaad.annotations;

@FunctionalInterface
public interface FunctionalTest {
    void test();
}
