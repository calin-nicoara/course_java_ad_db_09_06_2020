package ro.esolacad.javaad.codequality.lowcouplinghighcohesion;

class LowCouplingHighCohesion2 {
    private EmailService emailService;

    public void sendEmail() {
        // use email service
    }
}
