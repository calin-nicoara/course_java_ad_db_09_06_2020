package ro.esolacad.javaad.reflection;

public class ReflectionMain {

    public static void main(String[] args) {
//        final Class<ChildReflectionExample> childClass = ChildReflectionExample.class;
//
//        ChildReflectionExample childReflectionExample = new ChildReflectionExample("Bebe");


    }


}
