package ro.esolacad.javaad.reflection;

interface Shoutout {
    void shoutout();
}
