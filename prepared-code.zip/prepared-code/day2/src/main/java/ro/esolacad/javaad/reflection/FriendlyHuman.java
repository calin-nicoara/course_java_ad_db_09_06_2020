package ro.esolacad.javaad.reflection;

class FriendlyHuman implements Shoutout {
    public void shoutout() {
        System.out.println("Hello!");
    }
}
