package ro.esolacad.javaad.annotations;

@Deprecated
class DeprecatedClass {

    @Deprecated
    public void deprecatedMethod() {

    }
}
