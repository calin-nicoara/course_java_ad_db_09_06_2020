package ro.esolacad.javaad.codequality.lowcouplinghighcohesion;

class ClientService {
}
