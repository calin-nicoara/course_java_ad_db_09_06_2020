package ro.esolacad.javaad.codequality.lowcouplinghighcohesion;

class LowCouplingHighCohesion1 {

    private ClientService clientService;

    public void createClient() {
        // use client service
    }
}
