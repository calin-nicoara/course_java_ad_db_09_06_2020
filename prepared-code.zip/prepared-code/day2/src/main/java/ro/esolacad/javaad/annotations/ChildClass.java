package ro.esolacad.javaad.annotations;

class ChildClass extends ParentClass {

    public void eat() {
    }
}
