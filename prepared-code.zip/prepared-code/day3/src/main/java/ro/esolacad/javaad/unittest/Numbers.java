package ro.esolacad.javaad.unittest;

public class Numbers {
    public static boolean isOdd(int number) {
        return number % 2 != 0;
    }
}
